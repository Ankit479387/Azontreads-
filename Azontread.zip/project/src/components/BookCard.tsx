import React from 'react';
import { Heart, ShoppingCart } from 'lucide-react';

interface BookCardProps {
  title: string;
  author: string;
  price: number;
  coverUrl: string;
  rating: number;
}

export function BookCard({ title, author, price, coverUrl, rating }: BookCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
      <div className="relative aspect-[2/3] overflow-hidden">
        <img
          src={coverUrl}
          alt={title}
          className="object-cover w-full h-full"
        />
        <button className="absolute top-2 right-2 p-2 bg-white/80 rounded-full hover:bg-white">
          <Heart className="h-5 w-5 text-gray-600 hover:text-red-500" />
        </button>
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-lg leading-tight mb-1 truncate">
          {title}
        </h3>
        <p className="text-gray-600 text-sm mb-2">{author}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-1">
            {[...Array(5)].map((_, i) => (
              <span
                key={i}
                className={`text-sm ${
                  i < rating ? 'text-yellow-400' : 'text-gray-300'
                }`}
              >
                ★
              </span>
            ))}
          </div>
          <span className="font-bold text-lg">₹{price}</span>
        </div>
        <button className="mt-3 w-full bg-indigo-600 text-white py-2 rounded-lg flex items-center justify-center space-x-2 hover:bg-indigo-700">
          <ShoppingCart className="h-5 w-5" />
          <span>Add to Cart</span>
        </button>
      </div>
    </div>
  );
}