import React from 'react';
import { BookOpen } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
              Discover Your Next Favorite Book
            </h1>
            <p className="text-lg md:text-xl text-indigo-100 mb-8">
              Explore thousands of eBooks across all genres. Start your reading journey today.
            </p>
            <div className="flex space-x-4">
              <button className="bg-white text-indigo-600 px-6 py-3 rounded-lg font-semibold hover:bg-indigo-50 transition-colors">
                Browse Books
              </button>
              <button className="border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/10 transition-colors">
                Learn More
              </button>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <div className="relative">
              <div className="absolute inset-0 bg-white/10 backdrop-blur-lg rounded-lg transform rotate-6"></div>
              <div className="relative bg-white/20 backdrop-blur-xl p-6 rounded-lg shadow-xl">
                <BookOpen className="h-20 w-20 text-white mb-4" />
                <div className="space-y-4">
                  <div className="h-4 bg-white/30 rounded w-3/4"></div>
                  <div className="h-4 bg-white/30 rounded w-1/2"></div>
                  <div className="h-4 bg-white/30 rounded w-2/3"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white to-transparent"></div>
    </div>
  );
}